package mvc_jdbc_test.view;

import mvc_jdbc_test.entity.Customer;
import java.util.Scanner;

public class ModifyCustomerView {

    public Customer modifyCustomer() {
        Customer customer = new Customer();
        Scanner sc = new Scanner(System.in);  // Scanner 하나만 사용

        System.out.println("======== 고객 정보 수정 ========\n");

        System.out.print("고객이름 입력: ");
        String customerName = sc.nextLine();

        System.out.print("고객나이 입력: ");
        int customerAge = Integer.parseInt(sc.nextLine()); // nextLine 후 숫자로 변환

        System.out.print("고객등급 입력: ");
        String customerLevel = sc.nextLine();

        System.out.print("고객직업 입력: ");
        String customerJob = sc.nextLine();

        System.out.print("고객적립금 입력: ");
        int customerReward = sc.nextInt();

        customer.setCustomerName(customerName);
        customer.setAge(customerAge);
        customer.setLevel(customerLevel);
        customer.setJob(customerJob);
        customer.setReward(customerReward);

        return customer;
    }
}
