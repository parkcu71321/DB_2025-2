package mvc_jdbc_test.view;

import java.util.Scanner;

public class DeleteCustomerView {

    public String deleteCustomer() {
        Scanner sc = new Scanner(System.in);
        System.out.println("\n======== 고객 정보 삭제 ========\n");
        System.out.print("삭제할 고객아이디 입력:");
        String customerId = sc.nextLine();
        return customerId;
    }
}