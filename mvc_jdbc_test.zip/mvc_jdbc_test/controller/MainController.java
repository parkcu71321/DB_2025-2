package mvc_jdbc_test.controller;

import jdbc_test.JDBCConnector;
import mvc_jdbc_test.entity.Customer;
import mvc_jdbc_test.entity.Order;
import mvc_jdbc_test.view.*;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;

public class MainController {
    public static void main(String[] args) {
        Connection con = JDBCConnector.getConnection();
        inputCustomerAndView(con);
        updateCustomerAndView(con);
        deleteCustomerAndView(con);
    }

    public static void orderListAndView(Connection con) {
        ArrayList<Order> orderList = new ArrayList<Order>();
        String sql = "select 주문번호, 고객이름, 고객아이디, 배송지, 수량, 주문일자, 제품명  from 주문, 고객, 제품  where 주문.주문고객=고객.고객아이디 and 주문.주문제품=제품.제품번호";
        try {
            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            Order order = null;
            while (rs.next()) {
                order = new Order();
                order.setOrderNum(rs.getString("주문번호"));
                order.setCustomerName(rs.getString("고객이름"));
                order.setCustomerId(rs.getString("고객아이디"));
                order.setShippingAddress(rs.getString("배송지"));
                order.setQuantity(rs.getInt("수량"));
                order.setShippingDate(rs.getDate("주문일자"));
                order.setProductName(rs.getString("제품명"));
                orderList.add(order);
            }
            rs.close();
            ps.close();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        OrdersView.printHead();
        for (Order order : orderList) {
            OrdersView.printOrders(order);
        }

    }

    public static void customerListAndView(Connection con) {
        ArrayList<Customer> customerList = new ArrayList<Customer>();
        try {
            String sql = "select * from 고객";
            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            Customer customer = null;

            while (rs.next()) {
                customer = new Customer();
                customer.setCustomerId(rs.getString("고객아이디"));
                customer.setCustomerName(rs.getString("고객이름"));
                customer.setAge(rs.getInt("나이"));
                customer.setLevel(rs.getString("등급"));
                customer.setJob(rs.getString("직업"));
                customer.setReward(rs.getInt("적립금"));
                customerList.add(customer);
            }

        } catch (SQLException e) {
            System.out.println("Statement or SQL Error");
        }


        CustomerView customerView = new CustomerView();
        customerView.printHead();
        for (Customer customer: customerList){
            customerView.printCustomer(customer);
            System.out.println();
        }
        customerView.printFooter();
    }


    public static void inputCustomerAndView(Connection con) {
        Scanner sc = new Scanner(System.in);
        InputCustomerInfoView inputCustomer = new InputCustomerInfoView();
        while (true){

            Customer customer = inputCustomer.inputCustomerInfo();
            CustomerView customerView = new CustomerView();
            customerView.printHead();
            customerView.printCustomer(customer);
            customerView.printFooter();


            String sql = "insert into 고객 values(?,?,?,?,?,?)";

            try {
                PreparedStatement pstmt = con.prepareStatement(sql);
                pstmt.setString(1, customer.getCustomerId());
                pstmt.setString(2, customer.getCustomerName());
                pstmt.setInt(3, customer.getAge());
                pstmt.setString(4, customer.getLevel());
                pstmt.setString(5, customer.getJob());
                pstmt.setInt(6, customer.getReward());
                pstmt.executeUpdate();
                pstmt.close();
            } catch (SQLException e) {
                System.out.println("Statement or SQL Error");
            }
            System.out.print("프로그램 종료를 원하면 e를 입력:");

            String input = sc.nextLine();

            if(input.equals("e")){
                break;
            }
        }
        System.out.println("프로그램이 종료 되었습니다.");
    }

    public static void updateCustomerAndView(Connection con) {
        Scanner sc = new Scanner(System.in);
        ModifyCustomerView updateView = new ModifyCustomerView();
        CustomerView customerView = new CustomerView();

        while (true) {

            System.out.print("수정할 고객 아이디 입력: ");
            String customerId = sc.nextLine();

            Customer customer = updateView.modifyCustomer();
            customer.setCustomerId(customerId); // 기존 ID 유지

            String sql = "update 고객 set 고객이름=?, 나이=?, 등급=?, 직업=?, 적립금=? where 고객ID=?";
            try {
                PreparedStatement pstmt = con.prepareStatement(sql);
                pstmt.setString(1, customer.getCustomerName());
                pstmt.setInt(2, customer.getAge());
                pstmt.setString(3, customer.getLevel());
                pstmt.setString(4, customer.getJob());
                pstmt.setInt(5, customer.getReward());
                pstmt.setString(6, customer.getCustomerId());

                pstmt.executeUpdate();
                pstmt.close();
            } catch (SQLException e) {
                System.out.println("Statement or SQL Error");
            }

            customerView.printHead();
            customerView.printCustomer(customer);
            customerView.printFooter();

            System.out.print("프로그램 종료를 원하면 e를 입력: ");
            String input = sc.nextLine();
            if(input.equals("e")){
                break;
            }
        }
        System.out.println("수정 프로그램 종료");
    }


    public static void deleteCustomerAndView(Connection con) {
        Scanner sc = new Scanner(System.in);
        DeleteCustomerView deleteView = new DeleteCustomerView();

        while (true) {
            String customerIdDelete = deleteView.deleteCustomer();

            if (customerIdDelete == null || customerIdDelete.trim().isEmpty()) {
                System.out.println("유효한 고객 ID가 입력되지 않았습니다.");
            } else {
                try {
                    String deleteOrderSql = "delete from 주문 where 주문고객 = ?";
                    try (PreparedStatement orderPstmt = con.prepareStatement(deleteOrderSql)) {
                        orderPstmt.setString(1, customerIdDelete);
                        int ordersDeleted = orderPstmt.executeUpdate();
                        System.out.println("해당 고객의 주문 정보 " + ordersDeleted + "건이 삭제되었습니다.");
                    }

                    String deleteCustomerSql = "delete from 고객 where 고객아이디 = ?";
                    try (PreparedStatement customerPstmt = con.prepareStatement(deleteCustomerSql)) {
                        customerPstmt.setString(1, customerIdDelete);
                        int customersDeleted = customerPstmt.executeUpdate();

                        if (customersDeleted > 0) {
                            System.out.println("고객 ID '" + customerIdDelete + "'의 정보가 성공적으로 삭제되었습니다.");
                        } else {
                            System.out.println("고객 ID '" + customerIdDelete + "'를 찾을 수 없거나 이미 존재하지 않습니다.");
                        }
                    }
                } catch (SQLException e) {
                    System.out.println("Statement or SQL Error: " + e.getMessage());
                }
            }

            // 종료 확인
            System.out.print("프로그램 종료를 원하면 e를 입력: ");
            String input = sc.nextLine();
            if(input.equals("e")){
                break;
            }
        }
        System.out.println("삭제 프로그램 종료");
    }
}

